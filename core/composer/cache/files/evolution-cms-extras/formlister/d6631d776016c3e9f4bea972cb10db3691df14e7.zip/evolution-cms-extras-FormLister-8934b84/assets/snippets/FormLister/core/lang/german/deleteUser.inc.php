<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Sie m&uuml;ssen angemeldet sein, um Ihr Profil zu l&ouml;schen.';
$_lang['deleteUser.delete_failed'] = 'Benutzer konnte nicht gelöscht werden.';

return $_lang;
