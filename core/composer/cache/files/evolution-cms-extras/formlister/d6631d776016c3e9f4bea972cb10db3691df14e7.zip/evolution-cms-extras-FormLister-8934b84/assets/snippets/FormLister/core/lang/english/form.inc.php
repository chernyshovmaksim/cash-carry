<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Message has been sent. There\'s no need to send it again';
$_lang['form.submitLimit'] = 'You may send message again in ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'sec';
$_lang['form.dateFormat'] = 'm.d.Y \a\t H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Message was successfully sent [+form.date.value+]';
$_lang['form.form_failed'] = 'Message failed to send.';
return $_lang;
