<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Il messaggio è stato inviato. Non è necessario inviarlo di nuovo';
$_lang['form.submitLimit'] = 'È possibile inviare nuovamente il messaggio in ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'sec';
$_lang['form.dateFormat'] = 'd.m.Y \a\t H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Il messaggio è stato inviato con successo [+form.date.value+]';
$_lang['form.form_failed'] = 'Messaggio non inviato.';
return $_lang;
