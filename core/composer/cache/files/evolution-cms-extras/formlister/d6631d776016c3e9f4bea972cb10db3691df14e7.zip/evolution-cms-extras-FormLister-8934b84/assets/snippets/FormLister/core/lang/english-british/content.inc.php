<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Only registered users can create new records.';
$_lang['create.default_successTpl'] = '@CODE:The data was successfully saved.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Only the author can edit this record.';
$_lang['edit.default_badRecordTpl'] = '@CODE:You can\'t edit this record.';
$_lang['create.default_badGroupTpl'] = '@CODE:You do not have permission to create records.';
$_lang['edit.default_badGroupTpl'] = '@CODE:You do not have permission to edit records.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Only registered users can edit records.';
$_lang['edit.update_failed'] = 'An error occured whilst saving the data.';
$_lang['edit.update_success'] = 'The data was successfully saved.';

return $_lang;
