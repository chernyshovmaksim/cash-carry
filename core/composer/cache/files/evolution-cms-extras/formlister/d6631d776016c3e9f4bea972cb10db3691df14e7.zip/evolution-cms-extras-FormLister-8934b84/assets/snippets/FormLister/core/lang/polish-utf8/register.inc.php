<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

$_lang = array();
$_lang['register.registration_failed'] = 'Zakładanie konta zkończone niepowodzeniem.';
$_lang['register.default_successTpl'] = '@CODE:Konto zostało pomyślnie utworzone.';
$_lang['register.default_skipTpl'] = '@CODE:Posiadasz już konto.';

return $_lang;
