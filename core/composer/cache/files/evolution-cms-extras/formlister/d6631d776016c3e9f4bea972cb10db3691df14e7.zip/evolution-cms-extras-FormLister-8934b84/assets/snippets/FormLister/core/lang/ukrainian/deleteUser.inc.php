<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Ви повинні бути авторизовані для виконання цієї дії.';
$_lang['deleteUser.delete_failed'] = 'Не вдалося видалити користувача.';

return $_lang;
