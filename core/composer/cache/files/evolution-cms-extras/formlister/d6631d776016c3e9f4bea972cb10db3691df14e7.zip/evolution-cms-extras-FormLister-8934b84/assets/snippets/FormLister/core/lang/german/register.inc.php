<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

$_lang = array();
$_lang['register.registration_failed'] = 'Benutzerregistrierung fehlgeschlagen.';
$_lang['register.default_successTpl'] = '@CODE:Benutzer wurde erfolgreich registriert.';
$_lang['register.default_skipTpl'] = '@CODE:Du bist bereits registriert.';

return $_lang;
