<?php
/**
 * FormLister
 *
 * Form processor
 *
 * @category    snippet
 * @version     1.12.1
 * @license     http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal    @modx_category Content
 * @internal    @installset base, sample
 * @author      Pathologic (https://github.com/pathologic)
 */

return require MODX_BASE_PATH.'assets/snippets/FormLister/snippet.FormLister.php';