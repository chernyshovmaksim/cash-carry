<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'Gebruiker is geblokkeerd. Neem contact op met de Administrator.';
$_lang['login.user_failed'] = 'Verkeerde gebruikersnaam of wachtwoord.';
$_lang['login.default_skipTpl'] = '@CODE:Je bent al ingelogd.';
$_lang['login.user_notactivated'] = 'Gebruikersaccount is niet geactiveerd.';
return $_lang;
