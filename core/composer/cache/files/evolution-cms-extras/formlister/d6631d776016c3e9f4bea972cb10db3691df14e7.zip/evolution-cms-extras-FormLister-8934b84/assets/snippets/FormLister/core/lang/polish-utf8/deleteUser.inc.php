<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Zaloguj się aby móc usunąć swój profil.';
$_lang['deleteUser.delete_failed'] = 'Usuwanie profilu zakończone niepowodzeniem.';

return $_lang;
