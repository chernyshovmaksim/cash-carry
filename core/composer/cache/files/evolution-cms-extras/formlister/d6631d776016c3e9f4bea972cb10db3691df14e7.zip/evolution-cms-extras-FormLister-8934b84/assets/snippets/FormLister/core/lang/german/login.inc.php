<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'Der Benutzer ist blockiert, bitte kontaktieren Sie den Site-Administrator.';
$_lang['login.user_failed'] = 'Benutzername oder Passwort ist falsch.';
$_lang['login.default_skipTpl'] = '@CODE:Du bist bereits eingeloggt.';
$_lang['login.user_notactivated'] = 'Das Benutzerkonto ist nicht aktiviert.';
return $_lang;
