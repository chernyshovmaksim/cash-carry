<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['register.registration_failed'] = 'Не удалось зарегистрировать пользователя.';
$_lang['register.default_successTpl'] = '@CODE:Пользователь успешно зарегистрирован.';
$_lang['register.default_skipTpl'] = '@CODE:Вы уже зарегистрированы.';

return $_lang;
