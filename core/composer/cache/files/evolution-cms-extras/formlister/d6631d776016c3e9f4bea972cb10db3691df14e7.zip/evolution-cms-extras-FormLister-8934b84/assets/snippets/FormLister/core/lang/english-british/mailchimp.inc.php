<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['mc.subscription_failed'] = 'Subscription failed.';
$_lang['mc.default_successTpl'] = '@CODE:Thank you for subscribing to our mailing list!';

return $_lang;
