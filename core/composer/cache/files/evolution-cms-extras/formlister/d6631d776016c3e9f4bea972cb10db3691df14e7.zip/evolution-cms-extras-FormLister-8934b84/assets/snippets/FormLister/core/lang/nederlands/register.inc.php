<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

$_lang = array();
$_lang['register.registration_failed'] = 'Gebruikersregistratie mislukt.';
$_lang['register.default_successTpl'] = '@CODE:Gebruiker is succesvol geregistreerd.';
$_lang['register.default_skipTpl'] = '@CODE:Je bent al geregistreerd.';

return $_lang;
