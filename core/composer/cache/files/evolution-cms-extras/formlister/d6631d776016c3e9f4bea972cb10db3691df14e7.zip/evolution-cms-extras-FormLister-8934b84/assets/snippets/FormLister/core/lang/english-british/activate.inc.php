<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Your account is now active.';
$_lang['activate.default_reportTpl'] = '@CODE:To activate your account please use the following link: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'This user account doesn\'t need activating or can\'t be activated.';
$_lang['activate.update_failed'] = 'Failed to proceed.';
$_lang['activate.default_successTpl'] = '@CODE:The link to activate your account has been sent.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Your account is active.';

return $_lang;
