<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Twoje konto zostało aktywowane.';
$_lang['activate.default_reportTpl'] = '@CODE:Kliknij w ten link aby aktywować swoje konto: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'To konto nie potrzebuje aktywacji lub nie może zostać aktywowane.';
$_lang['activate.update_failed'] = 'Akcja zakończona niepowodzeniem.';
$_lang['activate.default_successTpl'] = '@CODE:Wiadomość z linkiem aktywacyjnym została wysłana na wskazany adres e-mail.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Twoje konto zostało aktywowane.';

return $_lang;
