<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Nur registrierte Benutzer k&ouml;nnen Datens&auml;tze l&ouml;schen.';
$_lang['deleteContent.default_successTpl'] = '@CODE:Die Daten wurden erfolgreich gel&ouml;scht.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Nur der Autor kann diesen Datensatz l&ouml;schen.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:Sie k&ouml;nnen diesen Datensatz nicht l&ouml;schen.';
$_lang['deleteContent.delete_failed'] = 'L&ouml;schen der Daten fehlgeschlagen.';

return $_lang;
