<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Only registered users can delete records.';
$_lang['deleteContent.default_successTpl'] = '@CODE:Data is deleted successfully.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Only author can delete this record.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:You cannot delete this record.';
$_lang['deleteContent.delete_failed'] = 'Data delete failed.';

return $_lang;
