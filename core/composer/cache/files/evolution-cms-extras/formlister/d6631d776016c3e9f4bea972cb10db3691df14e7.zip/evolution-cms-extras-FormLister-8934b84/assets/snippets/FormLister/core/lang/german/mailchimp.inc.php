<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['mc.subscription_failed'] = 'Abonnement fehlgeschlagen.';
$_lang['mc.default_successTpl'] = '@CODE:Vielen Dank f&uuml;r das Abonnieren unserer Mailingliste!';

return $_lang;
