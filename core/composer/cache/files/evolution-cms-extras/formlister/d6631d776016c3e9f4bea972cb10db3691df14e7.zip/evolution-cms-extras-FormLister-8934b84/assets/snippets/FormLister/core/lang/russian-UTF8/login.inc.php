<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['login.user_blocked'] = 'Пользователь заблокирован. Обратитесь к администратору сайта.';
$_lang['login.user_failed'] = 'Неверное имя пользователя или пароль.';
$_lang['login.default_skipTpl'] = '@CODE:Вы уже авторизованы.';
$_lang['login.user_notactivated'] = 'Учетная запись не активирована.';

return $_lang;
