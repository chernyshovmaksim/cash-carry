<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:You must be logged in to delete your profile.';
$_lang['deleteUser.delete_failed'] = 'User could not be deleted.';

return $_lang;
