<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Ihr Konto ist jetzt aktiv.';
$_lang['activate.default_reportTpl'] = '@CODE:Um Ihren Benutzerkonto zu aktivieren, benutzen Sie bitte den folgenden Link: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'Dieses Konto muss nicht, oder kann nicht aktiviert werden.';
$_lang['activate.update_failed'] = 'Fehler beim Fortfahren.';
$_lang['activate.default_successTpl'] = '@CODE:Der Link zum Aktivieren Ihres Kontos wurde gesendet.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Dein Benutzerkonto ist aktiv.';

return $_lang;
