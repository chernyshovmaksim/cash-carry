<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:Debes iniciar sesión para cambiar tu perfil.';
$_lang['profile.update_failed'] = 'La actualización del perfil falló.';
$_lang['profile.update_success'] = 'El perfil ha sido actualizado con éxito.';

return $_lang;
