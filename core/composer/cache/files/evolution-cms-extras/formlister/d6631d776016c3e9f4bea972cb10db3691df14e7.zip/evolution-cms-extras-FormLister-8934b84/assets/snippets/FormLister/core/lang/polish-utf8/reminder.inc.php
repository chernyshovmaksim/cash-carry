<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['reminder.default_skipTpl'] = '@CODE:Musisz się wylogować aby zresetować hasło.';
$_lang['reminder.default_reportTpl'] = '@CODE:Kliknij w ten link aby zresetować hasło: <a href="[+reset.url+]">[+reset.url+]</a>';
$_lang['reminder.users_only'] = 'Tylko zarejestrowani użytkownicy mogą zresetować hasło.';
$_lang['reminder.update_failed'] = 'Akcja zakończona niepowodzeniem.';
$_lang['reminder.default_successTpl'] = '@CODE:Wiadomość z linkiem resetującym hasło została wysłana na wskazany adres e-mail.';
$_lang['reminder.default_resetSuccessTpl'] = '@CODE:Nowe hasło zostało wysłane na wskazany adres e-mail.';

return $_lang;
