<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Alleen geregistreerde gebruikers kunnen records verwijderen Data wordt succesvol opgeslagen.';
$_lang['deleteContent.default_successTpl'] = '@CODE:Gegevens worden met succes verwijderd.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Alleen auteur kan deze record verwijderen.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:U kunt dit record niet verwijderen.';
$_lang['deleteContent.delete_failed'] = 'Gegevens verwijderen mislukt.';

return $_lang;
