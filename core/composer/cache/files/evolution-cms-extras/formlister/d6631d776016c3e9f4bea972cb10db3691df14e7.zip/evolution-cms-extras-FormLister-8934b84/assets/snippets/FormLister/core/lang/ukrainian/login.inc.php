<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['login.user_blocked'] = 'Користувач заблокований. Зверніться до адміністратора сайту.';
$_lang['login.user_failed'] = 'Неправильне ім\'я користувача або пароль.';
$_lang['login.default_skipTpl'] = '@CODE:Ви вже авторизовані.';
$_lang['login.user_notactivated'] = 'Обліковий запис не активовано.';

return $_lang;
