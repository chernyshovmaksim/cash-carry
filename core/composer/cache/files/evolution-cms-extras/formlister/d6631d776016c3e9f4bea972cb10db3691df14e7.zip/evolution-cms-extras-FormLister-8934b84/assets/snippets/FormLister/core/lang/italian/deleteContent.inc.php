<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Solo gli utenti registrati possono cancellare i record.';
$_lang['deleteContent.default_successTpl'] = '@CODE:I dati sono stati cancellati con successo.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Solo l\'autore può cancellare questo record.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:Non puoi cancellare questo record.';
$_lang['deleteContent.delete_failed'] = 'Cancellazione dei dati fallita.';

return $_lang;
