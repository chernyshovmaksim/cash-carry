<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:You must be logged in to change your profile.';
$_lang['profile.update_failed'] = 'Profile update failed.';
$_lang['profile.update_success'] = 'Profile has been updated successfully.';

return $_lang;
