<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Debes iniciar sesión para eliminar tu perfil.';
$_lang['deleteUser.delete_failed'] = 'El usuario no pudo ser eliminado.';

return $_lang;
