# FormLister

FormLister is a form processor for Evolution CMS.

Use Extras module to install FormLister.

Disable userHelper plugin if you are not using FormLister components to manage web users.

[Official docs (en)](https://github.com/Pathologic/FormLister/tree/master/assets/snippets/FormLister/docs/en)
[Official docs (ru)](https://github.com/Pathologic/FormLister/tree/master/assets/snippets/FormLister/docs/ru)
[Community docs (en)](http://www.evolution-docs.com/extras/formlister/)
[Examples (ru)](https://github.com/Pathologic/FormLister/tree/master/assets/snippets/FormLister/docs/examples/ru)
[Changelog (ru)](https://github.com/Pathologic/FormLister/blob/master/assets/snippets/FormLister/docs/history.md)
