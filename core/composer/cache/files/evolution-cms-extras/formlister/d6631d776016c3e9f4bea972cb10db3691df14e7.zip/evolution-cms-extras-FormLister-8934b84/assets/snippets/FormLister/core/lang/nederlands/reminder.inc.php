<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['reminder.default_skipTpl'] = '@CODE:U moet uitloggen om uw wachtwoord te herstellen.';
$_lang['reminder.default_reportTpl'] = '@CODE:Om uw wachtwoord te herstellen, gaat u verder met de link: <a href="[+reset.url+]">[+reset.url+]</a>';
$_lang['reminder.users_only'] = 'Alleen geregistreerde gebruikers kunnen wachtwoorden herstellen.';
$_lang['reminder.update_failed'] = 'Kan niet doorgaan.';
$_lang['reminder.default_successTpl'] = '@CODE:De link om uw wachtwoord te herstellen is gemaild.';
$_lang['reminder.default_resetSuccessTpl'] = '@CODE:Nieuw wachtwoord is gemaild.';

return $_lang;
