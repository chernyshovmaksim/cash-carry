<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['register.registration_failed'] = 'Не вдалося зареєструвати користувача.';
$_lang['register.default_successTpl'] = '@CODE:Користувач успішно зареєстрований.';
$_lang['register.default_skipTpl'] = '@CODE:Ви вже зареєстровані.';

return $_lang;
