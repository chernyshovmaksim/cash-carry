<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:Devi essere loggato per cambiare il tuo profilo.';
$_lang['profile.update_failed'] = 'Aggiornamento del profilo fallito.';
$_lang['profile.update_success'] = 'Il profilo è stato aggiornato con successo.';

return $_lang;
