<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Bericht is verzonden. Het is niet nodig om het opnieuw te verzenden';
$_lang['form.submitLimit'] = 'U kunt binnen opnieuw bericht verzenden ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'sec';
$_lang['form.dateFormat'] = 'd-m-Y';
$_lang['form.default_successTpl'] = '@CODE:Bericht is succesvol verzonden [+form.date.value+]';
$_lang['form.form_failed'] = 'Bericht kan niet worden verzonden.';
return $_lang;
