<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Вы должны быть авторизованы для выполнения этого действия.';
$_lang['deleteUser.delete_failed'] = 'Не удалось удалить пользователя.';

return $_lang;
