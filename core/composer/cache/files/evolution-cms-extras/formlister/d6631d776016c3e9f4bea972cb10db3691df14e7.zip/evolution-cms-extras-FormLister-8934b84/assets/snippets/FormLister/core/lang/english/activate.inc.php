<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Your account is activated.';
$_lang['activate.default_reportTpl'] = '@CODE:To activate your account proceed the link: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'This user account need no activation or cannot be activated.';
$_lang['activate.update_failed'] = 'Failed to proceed.';
$_lang['activate.default_successTpl'] = '@CODE:The link to activate your account has been mailed.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Your account is activated.';

return $_lang;
