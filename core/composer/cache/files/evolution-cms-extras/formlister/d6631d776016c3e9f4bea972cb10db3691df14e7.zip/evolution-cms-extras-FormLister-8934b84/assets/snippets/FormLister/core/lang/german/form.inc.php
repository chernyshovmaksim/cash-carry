<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Ihre Nachricht wurde gesendet, es besteht Keine Notwendigkeit es erneut zu senden';
$_lang['form.submitLimit'] = 'Sie k&ouml;nnen Ihre Nachricht erneut senden in ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'sek';
$_lang['form.dateFormat'] = 'd.m.Y \u\m H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Ihre Nachricht wurde am [+form.date.value+] erfolgreich gesendet';
$_lang['form.form_failed'] = 'Ihre Nachricht konnte nicht gesendet werden.';
return $_lang;
