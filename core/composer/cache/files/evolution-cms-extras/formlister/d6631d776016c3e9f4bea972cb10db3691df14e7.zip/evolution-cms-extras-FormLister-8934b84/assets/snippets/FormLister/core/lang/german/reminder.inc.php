<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['reminder.default_skipTpl'] = '@CODE:Sie m&uuml;ssen sich abmelden, um Ihr Passwort wiederherzustellen.';
$_lang['reminder.default_reportTpl'] = '@CODE:Verwenden Sie den folgenden Link, um Ihr Passwort wiederherzustellen: <a href="[+reset.url+]">[+reset.url+]</a>';
$_lang['reminder.users_only'] = 'Nur registrierte Benutzer k&ouml;nnen Passw&ouml;rter wiederherstellen.';
$_lang['reminder.update_failed'] = 'Fehler beim Fortfahren.';
$_lang['reminder.default_successTpl'] = '@CODE:Der Link zum Wiederherstellen Ihres Passworts wurde gesendet.';
$_lang['reminder.default_resetSuccessTpl'] = '@CODE:Das neue Passwort wurde gesendet.';

return $_lang;
