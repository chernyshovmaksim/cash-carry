<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

$_lang = array();
$_lang['register.registration_failed'] = 'Registrazione utente fallita.';
$_lang['register.default_successTpl'] = '@CODE:L\'utente è stato registrato con successo.';
$_lang['register.default_skipTpl'] = '@CODE:Sei già registrato.';

return $_lang;
