<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['mc.subscription_failed'] = 'Inschrijving mislukt.';
$_lang['mc.default_successTpl'] = '@CODE:Bedankt voor het aanmelden op onze mailinglijst!';

return $_lang;
