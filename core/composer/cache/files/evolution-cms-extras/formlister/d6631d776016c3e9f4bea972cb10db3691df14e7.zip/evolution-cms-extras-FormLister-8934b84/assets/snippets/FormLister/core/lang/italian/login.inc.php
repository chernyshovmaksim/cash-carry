<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'Utente bloccato. Si prega di contattare l\'amministratore del sito.';
$_lang['login.user_failed'] = 'Nome utente o password errati.';
$_lang['login.default_skipTpl'] = '@CODE:Sei già loggato.';
$_lang['login.user_notactivated'] = 'Account utente non attivato.';
return $_lang;
