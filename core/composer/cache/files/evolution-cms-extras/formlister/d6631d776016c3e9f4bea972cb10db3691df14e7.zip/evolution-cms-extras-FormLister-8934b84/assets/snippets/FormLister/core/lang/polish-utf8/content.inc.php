<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Tylko zarejestrowani użytkownicy mogą dodawać treść.';
$_lang['create.default_successTpl'] = '@CODE:Treść została pomyślnie zapisana.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Tylko autor może edytować tę treść.';
$_lang['edit.default_badRecordTpl'] = '@CODE:Nie możesz edytować tej treści.';
$_lang['create.default_badGroupTpl'] = '@CODE:Nie posiadasz uprawnień do dodawania treści.';
$_lang['edit.default_badGroupTpl'] = '@CODE:Nie posiadasz uprawnień do edycji treści.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Tylko zarejestrowani użytkownicy mogą edytować treści.';
$_lang['edit.update_failed'] = 'Zapisywanie zakończone niepowodzeniem.';
$_lang['edit.update_success'] = 'Treść została pomyślnie zapisana.';

return $_lang;
