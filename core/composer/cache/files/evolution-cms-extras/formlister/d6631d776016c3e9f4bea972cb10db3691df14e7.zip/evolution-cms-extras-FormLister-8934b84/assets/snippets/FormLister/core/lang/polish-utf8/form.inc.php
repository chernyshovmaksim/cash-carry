<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Wiadomość została wysłana. Nie ma potrzeby wysyłać jej ponownie';
$_lang['form.submitLimit'] = 'Możesz wysłać wiadomość ponownie za ';
$_lang['form.minutes'] = 'min.';
$_lang['form.seconds'] = 'sek.';
$_lang['form.dateFormat'] = 'd.m.Y \a\t H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Wiadomość pomyślnie wysłana [+form.date.value+]';
$_lang['form.form_failed'] = 'Wysyłanie wiadomości zakończone niepowodzeniem.';
return $_lang;
