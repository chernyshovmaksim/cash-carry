<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 3:26
 */

$_lang = array();
$_lang['register.registration_failed'] = 'El registro del usuario falló.';
$_lang['register.default_successTpl'] = '@CODE:El usuario ha sido registrado con éxito.';
$_lang['register.default_skipTpl'] = '@CODE:Usted ya está registrado.';

return $_lang;
