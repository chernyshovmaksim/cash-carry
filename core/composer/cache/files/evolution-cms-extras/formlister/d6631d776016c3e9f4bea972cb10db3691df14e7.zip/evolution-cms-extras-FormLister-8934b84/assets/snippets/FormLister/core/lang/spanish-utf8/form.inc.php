<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Su mensaje ha sido enviado, no hay necesidad de enviarlo de nuevo';
$_lang['form.submitLimit'] = 'Puede enviar su mensaje nuevamente en ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'seg';
$_lang['form.dateFormat'] = 'd.m.Y \a\t H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Su mensaje fue enviado con éxito el [+form.date.value+]';
$_lang['form.form_failed'] = 'Su mensaje no pudo ser enviado.';
return $_lang;
