<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Uw account is geactiveerd.';
$_lang['activate.default_reportTpl'] = '@CODE:Om uw account te activeren, gaat u verder via deze link: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'Dit gebruikersaccount hoeft niet te worden geactiveerd of kan niet worden geactiveerd.';
$_lang['activate.update_failed'] = 'Update mislukt.';
$_lang['activate.default_successTpl'] = '@CODE:De link om uw account te activeren is gemaild.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Uw account is geactiveerd.';

return $_lang;
