<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Nur registrierte Benutzer k&ouml;nnen Beitr&auml;ge erstellen.';
$_lang['create.default_successTpl'] = '@CODE:Die Daten wurden erfolgreich gespeichert.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Nur der Autor kann diesen Datensatz bearbeiten.';
$_lang['edit.default_badRecordTpl'] = '@CODE:Sie k&ouml;nnen diesen Datensatz nicht bearbeiten.';
$_lang['create.default_badGroupTpl'] = '@CODE:Sie sind nicht berechtigt, Datens&auml;tze zu erstellen.';
$_lang['edit.default_badGroupTpl'] = '@CODE:Sie sind nicht berechtigt, Datens&auml;tze zu bearbeiten.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Nur registrierte Benutzer k&ouml;nnen Datens&auml;tze bearbeiten.';
$_lang['edit.update_failed'] = 'Fehler beim Speichern der Daten.';
$_lang['edit.update_success'] = 'Daten wurden erfolgreich gespeichert.';

return $_lang;
