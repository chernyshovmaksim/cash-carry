<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:U moet zijn aangemeld om uw profiel te wijzigen.';
$_lang['profile.update_failed'] = 'Profielupdate mislukt.';
$_lang['profile.update_success'] = 'Profiel is succesvol bijgewerkt.';

return $_lang;
