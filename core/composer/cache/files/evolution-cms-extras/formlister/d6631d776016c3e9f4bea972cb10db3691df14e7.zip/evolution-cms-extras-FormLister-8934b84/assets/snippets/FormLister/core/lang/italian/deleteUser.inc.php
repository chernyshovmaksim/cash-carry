<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Devi effettuare il login per cancellare il tuo profilo.';
$_lang['deleteUser.delete_failed'] = 'Eliminazione profilo non riuscita.';

return $_lang;
