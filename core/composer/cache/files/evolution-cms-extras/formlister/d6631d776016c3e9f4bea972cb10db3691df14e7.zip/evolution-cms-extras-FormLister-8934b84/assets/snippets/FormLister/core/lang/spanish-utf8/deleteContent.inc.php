<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Solo los usuarios registrados pueden borrar registros.';
$_lang['deleteContent.default_successTpl'] = '@CODE:La información fue eliminada don éxito.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Solo el autor puede eliminar este registro.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:No puedes borrar este registro.';
$_lang['deleteContent.delete_failed'] = 'Error en la eliminación de datos.';

return $_lang;
