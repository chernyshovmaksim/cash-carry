<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['mc.subscription_failed'] = 'Не вдалося додати вас до списку підписників.';
$_lang['mc.default_successTpl'] = '@CODE:Дякуємо, що підписалися на нашу розсилку!';

return $_lang;
