<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Su cuenta ahora está activa.';
$_lang['activate.default_reportTpl'] = '@CODE:Para activar su cuenta, utilice el siguiente enlace: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'Esta cuenta de usuario no necesita activación o no puede ser activada.';
$_lang['activate.update_failed'] = 'Fallo al proceder.';
$_lang['activate.default_successTpl'] = '@CODE:El enlace para activar su cuenta ha sido enviado.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Tu cuenta está activa.';

return $_lang;
