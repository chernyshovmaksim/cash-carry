<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:Sie m&uuml;ssen angemeldet sein, um Ihr Profil zu &auml;ndern.';
$_lang['profile.update_failed'] = 'Die Profilaktualisierung ist fehlgeschlagen.';
$_lang['profile.update_success'] = 'Das Profil wurde erfolgreich aktualisiert.';

return $_lang;
