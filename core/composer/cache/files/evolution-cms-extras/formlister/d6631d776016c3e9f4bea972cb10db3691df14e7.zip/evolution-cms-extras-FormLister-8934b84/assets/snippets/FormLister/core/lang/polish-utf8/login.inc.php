<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'Użytkownik zablokowany. Skontaktuj się z administratorem.';
$_lang['login.user_failed'] = 'Błędna nazwa użytkownika lub hasło.';
$_lang['login.default_skipTpl'] = '@CODE:Jesteś już zalogowany.';
$_lang['login.user_notactivated'] = 'Konto nie zostało aktywowane.';
return $_lang;
