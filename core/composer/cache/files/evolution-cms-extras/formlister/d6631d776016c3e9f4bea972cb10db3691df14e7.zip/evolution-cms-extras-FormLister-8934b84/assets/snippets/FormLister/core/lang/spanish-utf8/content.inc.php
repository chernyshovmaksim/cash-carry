<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Solo los usuarios registrados pueden crear nuevos registros.';
$_lang['create.default_successTpl'] = '@CODE:Los datos se guardaron con éxito.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Solo el autor puede editar este registro.';
$_lang['edit.default_badRecordTpl'] = '@CODE:No puedes editar este registro.';
$_lang['create.default_badGroupTpl'] = '@CODE:No tienes permiso para crear registros.';
$_lang['edit.default_badGroupTpl'] = '@CODE:No tienes permiso para editar registros.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Solo los usuarios registrados pueden editar registros.';
$_lang['edit.update_failed'] = 'Se produjo un error al guardar los datos.';
$_lang['edit.update_success'] = 'Los datos se guardaron con éxito.';

return $_lang;
