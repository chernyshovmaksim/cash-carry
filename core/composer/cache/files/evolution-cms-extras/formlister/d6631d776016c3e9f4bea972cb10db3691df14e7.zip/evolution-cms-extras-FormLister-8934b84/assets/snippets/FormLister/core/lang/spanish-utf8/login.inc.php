<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'El usuario está bloqueado, contáctese con el administrador del sitio.';
$_lang['login.user_failed'] = 'Nombre de usuario o contraseña incorrectos.';
$_lang['login.default_skipTpl'] = '@CODE:Ya se ha autentificado.';
$_lang['login.user_notactivated'] = 'La cuenta de usuario no está activada.';
return $_lang;
