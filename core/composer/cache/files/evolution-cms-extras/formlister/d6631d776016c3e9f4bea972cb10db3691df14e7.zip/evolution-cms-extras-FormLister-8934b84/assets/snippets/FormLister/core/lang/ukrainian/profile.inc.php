<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:Для зміни профілю ви повинні бути авторизовані.';
$_lang['profile.update_failed'] = 'Невдалось зберегти дані.';
$_lang['profile.update_success'] = 'Дані успішно збережені.';

return $_lang;
