<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteContent.default_skipTpl'] = '@CODE:Tylko zarejestrowani użytkownicy mogą usuwać treści.';
$_lang['deleteContent.default_successTpl'] = '@CODE:Treść została pomyślnie usunięta.';
$_lang['deleteContent.default_badOwnerTpl'] = '@CODE:Tylko autor może usunąć tę treść.';
$_lang['deleteContent.default_badRecordTpl'] = '@CODE:Nie możesz usunąć tej treści.';
$_lang['deleteContent.delete_failed'] = 'Usuwanie treści zakończone niepowodzeniem.';

return $_lang;
