<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Alleen geregistreerde gebruikers kunnen nieuwe records maken.';
$_lang['create.default_successTpl'] = '@CODE:Gegevens zijn succesvol opgeslagen.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Alleen de auteur kan deze record bewerken.';
$_lang['edit.default_badRecordTpl'] = '@CODE:Je kunt deze record niet bewerken.';
$_lang['create.default_badGroupTpl'] = '@CODE:U mag geen records maken.';
$_lang['edit.default_badGroupTpl'] = '@CODE:U mag geen records bewerken.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Alleen geregistreerde gebruikers kunnen records bewerken.';
$_lang['edit.update_failed'] = 'Gegevens opslaan mislukt.';
$_lang['edit.update_success'] = 'Gegevens worden succesvol opgeslagen.';

return $_lang;
