<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 21.05.2016
 * Time: 11:51
 */

$_lang = array();
$_lang['activate.default_skipTpl'] = '@CODE:Il tuo account è stato attivato.';
$_lang['activate.default_reportTpl'] = '@CODE:Per attivare il tuo account, procedi con il link: <a href="[+activate.url+]">[+activate.url+]</a>';
$_lang['activate.no_activation'] = 'Questo account utente non ha bisogno di attivazione o non può essere attivato.';
$_lang['activate.update_failed'] = 'Impossibile procedere.';
$_lang['activate.default_successTpl'] = '@CODE:Il link per attivare il tuo account è stato inviato via mail.';
$_lang['activate.default_resetSuccessTpl'] = '@CODE:Il tuo account è attivato.';

return $_lang;
