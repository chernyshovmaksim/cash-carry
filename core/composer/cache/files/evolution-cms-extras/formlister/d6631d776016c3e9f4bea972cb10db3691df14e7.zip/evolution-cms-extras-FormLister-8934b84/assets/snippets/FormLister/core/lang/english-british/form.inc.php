<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['form.protectSubmit'] = 'Your message has been sent, there\'s no need to send it again';
$_lang['form.submitLimit'] = 'You may send your message again in ';
$_lang['form.minutes'] = 'min';
$_lang['form.seconds'] = 'sec';
$_lang['form.dateFormat'] = 'd.m.Y \a\t H:i:s';
$_lang['form.default_successTpl'] = '@CODE:Your message was successfully sent on the [+form.date.value+]';
$_lang['form.form_failed'] = 'Your message could not be sent.';
return $_lang;
