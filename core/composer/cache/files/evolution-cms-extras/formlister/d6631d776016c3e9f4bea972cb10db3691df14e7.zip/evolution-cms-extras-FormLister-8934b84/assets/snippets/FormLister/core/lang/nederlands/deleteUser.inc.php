<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['deleteUser.default_skipTpl'] = '@CODE:Je moet ingelogd zijn om je profiel te verwijderen.';
$_lang['deleteUser.delete_failed'] = 'Profiel verwijderen is mislukt.';

return $_lang;
