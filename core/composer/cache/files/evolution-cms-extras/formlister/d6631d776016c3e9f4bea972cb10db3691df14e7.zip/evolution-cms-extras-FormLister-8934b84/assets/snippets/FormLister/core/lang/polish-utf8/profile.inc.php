<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['profile.default_skipTpl'] = '@CODE:Musisz się zalogować aby edytować swój profil.';
$_lang['profile.update_failed'] = 'Aktualizacja profilu zakończona niepowodzeniem.';
$_lang['profile.update_success'] = 'Profil został pomyślnie zaktualizowany.';

return $_lang;
