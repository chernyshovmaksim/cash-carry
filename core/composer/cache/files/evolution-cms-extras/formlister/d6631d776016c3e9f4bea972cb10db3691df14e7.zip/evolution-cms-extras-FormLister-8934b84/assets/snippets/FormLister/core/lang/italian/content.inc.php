<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['create.default_skipTpl'] = '@CODE:Solo gli utenti registrati possono creare nuovi record.';
$_lang['create.default_successTpl'] = '@CODE:Dati salvati correttamente.';
$_lang['edit.default_badOwnerTpl'] = '@CODE:Solo l\'autore può modificare questo record.';
$_lang['edit.default_badRecordTpl'] = '@CODE:Non puoi modificare questo record.';
$_lang['create.default_badGroupTpl'] = '@CODE:Non sei autorizzato a creare record.';
$_lang['edit.default_badGroupTpl'] = '@CODE:Non sei autorizzato a modificare i record.';
$_lang['edit.default_skipEditTpl'] = '@CODE:Solo gli utenti registrati possono modificare i record.';
$_lang['edit.update_failed'] = 'Salvataggio dei dati fallito.';
$_lang['edit.update_success'] = 'Dati salvati correttamente.';

return $_lang;
