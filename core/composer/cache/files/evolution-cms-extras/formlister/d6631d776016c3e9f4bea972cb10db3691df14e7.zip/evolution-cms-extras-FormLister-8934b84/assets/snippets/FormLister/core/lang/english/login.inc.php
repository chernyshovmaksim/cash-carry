<?php
/**
 * Created by PhpStorm.
 * User: Pathologic
 * Date: 15.05.2016
 * Time: 1:26
 */

$_lang = array();
$_lang['login.user_blocked'] = 'User is blocked. Contact site administrator.';
$_lang['login.user_failed'] = 'Wrong user name or password.';
$_lang['login.default_skipTpl'] = '@CODE:You are already logged in.';
$_lang['login.user_notactivated'] = 'User account is not activated.';
return $_lang;
