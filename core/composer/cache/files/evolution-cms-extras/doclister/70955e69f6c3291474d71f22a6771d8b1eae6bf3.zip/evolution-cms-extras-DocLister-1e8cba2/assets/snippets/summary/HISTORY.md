Changelog for summary package.

summary 1.0.3
====================================
- fix html entities at the end of the text

summary 1.0.2
====================================
- Add dotted scheme parameter 
- Fix <cut /> && strip_tags
- Add cut parameter


summary 1.0.1
====================================
- Fix empty parameter
- Fix <cut /> and TinyMCE
- Add documentation

summary 1.0.0
=====================================
- Initial commit