<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

$_lang = array();
$_lang['hello'] = 'こんにちは';

return $_lang;
