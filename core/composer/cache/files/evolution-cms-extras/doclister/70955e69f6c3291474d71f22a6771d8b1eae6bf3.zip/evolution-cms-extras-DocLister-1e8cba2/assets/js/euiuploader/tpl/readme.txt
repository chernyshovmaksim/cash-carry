1. Install the Handlebars commandline script:
npm install -g handlebars

2. Go to assets/plugins/simplegallery/js/tpl/

3. Compile templates:
handlebars *.handlebars -f templates.js -m