<?php
/**
 * DLCrumbs
 *
 * DLCrumbs
 *
 * @category 	snippet
 * @version 	1.2
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@properties
 * @internal	@modx_category Navigation
 * @internal    @installset base, sample
 */

return require MODX_BASE_PATH.'assets/snippets/DocLister/snippet.DLCrumbs.php';
