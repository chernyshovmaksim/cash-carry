<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modSnippet
 */
class modSnippet extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_snippets";
}
