# SimpleTab
Extend document tabs with OnDocFormRender plugins using EasyUI:
https://github.com/Pathologic/SimpleGallery - fast and flexible image gallery
https://github.com/Pathologic/SimpleTube - to manage YouTube, RuTube, Vimeo etc. videos with automatic thumbnails download
https://github.com/Pathologic/SimpleFiles - file archive
